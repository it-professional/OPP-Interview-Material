<?php
$con = mysqli_connect("localhost","root","","testing") or die('Error in SQL Connection');
$query = mysqli_query($con,'Call result_checking(4)');
if(mysqli_num_rows($query) > 0){
	while($row = mysqli_fetch_array($query)){
		echo "<br>subject id is: ".$row['sub_id'];
		echo "result is: ".$row['result'];
	}
}
?>