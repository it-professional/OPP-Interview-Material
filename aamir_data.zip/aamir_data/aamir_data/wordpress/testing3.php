<?php
//include("testing2.php");

$string = "Muhammad Aamir Rasheed";
echo "Orgional String is: <br>";
echo $string;
echo "<br><br><br><br>";


//echo "fav color is: ".$favcolor;
//echo "<br><br>global variables are: ";
//print_r($GLOBALS);


/*echo "<br>current file path is: ".$_SERVER['PHP_SELF'];
echo "<br>current file path is: ".$_SERVER['SERVER_ADDR'];
echo "<br>current file path is: ".$_SERVER['SERVER_NAME'];
echo "<br>current file path is: ".$_SERVER['REQUEST_METHOD'];
echo "<br>current file path is: ".$_SERVER['QUERY_STRING'];
echo "<br>current file path is: ".$_SERVER['REMOTE_ADDR'];
//echo "<br>current file path is: ".$_SERVER['REMOTE_HOST'];
echo "<br>current file path is: ".$_SERVER['SCRIPT_NAME'];
echo "<br>current file path is: ".$_SERVER['SCRIPT_URI'];*/



/*echo '<table>
  <tr>
    <td>Filter Name</td>
    <td>Filter ID</td>
  </tr>';
  foreach (filter_list() as $id =>$filter) {
      echo '<tr><td>' . $filter . '</td><td>' . filter_id($filter) . '</td></tr>';
  }
  
echo '</table>'; */

$a = "<script language='javascript' type='text/javascript'>alert('hacked');</script>";
//echo $a;




/*class CustomException extends Exception{
	public function testMessage(){
		return "This message is from test custom exception class.";
	}
}


$email = "aamirexample.test";
try{
	if(filter_var($email, FILTER_VALIDATE_EMAIL) === FALSE){
		throw new Exception("Email is invalid");
	}else{
		echo "<br><br>in else condition";
	}
}
catch(CustomException $e){
	echo "Error Message is: ".$e->testMessage();
}
catch(Exception $e){
	echo "<br><br>Exception Message is: ".$e->getMessage();
}*/

/*class parentclass{
	public $a ;
	protected $b ;
	protected $c ;
		
	function __construct(){
		$this->a = 10;
		$this->b = 20;
		$this->c = 30;
	}
	
	function sum(){
		$d = $this->a + $this->b + $this->c  ;
		echo "sum of result is: ".$d;
	}
}

$object = new parentclass();


$object->sum();

//echo "<br><br>public value is: ".$object->a;
//echo "<br><br>protected value is: ".$object->b;
//echo "<br><br>private value is: ".$object->c;

class childclass extends parentclass{
	function __construct(){
	parent::__construct();
	}
	
	function sum2(){
		echo "in function sum2 variable a value is: ".$this->a;
		echo "<br><br>in function sum2 protected v value is: ".$this->b;
		echo "<br><br>in function sum2 protected c value is: ".$this->c;
	}
}
$oj = new childclass();
$oj->sum2();*/

/*class TestClass
{
    public $testVar = "test default value";
    public function __construct()
    {
      // $this->testVar = $varValue;               
    }
	function abc(){
		echo $this->testVar;
	}
}    
$object = new TestClass();
print $object->abc();
*/


//$a = function(){echo 'hello world';};
//echo $a();


//echo "<br><br><br>";

/*class testmagicmethods{
	public $first_name = '';
	public $last_name = '';
	
	function __construct(){
		$this->first_name = 'aamir';
		$this->last_name = 'rasheed';
	}
	
	function testing(){
		$test_function_var = "this is a functional variable";
		echo $test_function_var ;
	}
	
	public function __get($property)
	{
		return $this->$property;
	}
	
	public function __set($property, $value)
	{
		$this->$property = $value;
	}
	
	public function __toString(){
		return $this->first_name;
	}
}

$object = new testmagicmethods();
$object->testing();*/

//$object->testing = $object->first_name.' '.$object->last_name;
//echo "<br>first name is: testing: ".$object->testing ;

//echo "full object is: ".$object;


//define('testvar','bad boy');

//echo "Test var value is: ".constant('testvar') ;

/*$var = 10;
switch($var){
	default:
		echo "this is default case";
		break;
	case ($var > 20):
		echo "The value is greater then 20";
		break;
	case($var < 8):
		echo "The value is less then 20";
	case ($var == 8):
		echo "<br><br>Value is 10 now";
		break;
}*/

//echo "random value is: ".srand(10);


//echo "cookies are: ";
//print_r($_COOKIE);
//setcookie('testcookname','interview');
//echo "<br><br><br><br>new updated cookie value is: <br>";
//print_r($_COOKIE);

//global $test_Var;
//$test_Var = "this is a global test variable";





//echo "<br><br><br><br><br><br>new testing <br><br><br>";
/*abstract class access_modifiers{
	public $b = "Aamir"; 
	
	public function __construct(){
		$this->a = "Mine Name";
	}
	 
	 function __toString(){
		return "this is testing access modifiers";
	}
}
*///$test = new access_modifiers();
//echo "value of a is: ".$test->a;
//echo "value of b is: ".$test->b;

/*class testing extends access_modifiers{
	
	public function fullname(){
		return "My name is: ".$this->a;
	}
}

$child_obj = new testing();
echo "<br><br>value is: ".$child_obj->fullname();
*/




class parentclass{
	public $a ;
	protected $b ;
	protected $c ;
		
	function __construct(){
		$this->a = 10;
		$this->b = 20;
		$this->c = 30;
	}
	
	 function sum(){
		$d = $this->a + $this->b + $this->c  ;
		return "sum of result is: ".$d;
	}
}

class childclass extends parentclass{
	function __construct(){
	parent::__construct();
	}
	
	function sum(){
		echo "<br><br>parent function sum is: ".parent::sum() ;
		echo "<br><br><br>in function sum2 variable a value is: ".$this->a;
		echo "<br><br>in function sum2 protected v value is: ".$this->b;
		echo "<br><br>in function sum2 protected c value is: ".$this->c;
	}
}

$object = new parentclass();
$oj = new childclass();
//$oj->sum();


class static_testing{
	public $var1 = 1;
	static $var2 = 1;
	const var3 = 1;
	
	public function testing(){
		$this->var1 = $this->var1 + 1;
		self::$var2 = self::$var2 + 1;
		//self::var3 = self::var3 ;
	}
	
	public function results(){
		$this->testing();
		//echo "<br>public variable value is: ".$this->var1;
		//echo "<br>static variable value is: ".self::$var2;
		//echo "<br>constant variable value is: ".self::var3;
	}
	
	public static function updated_results(){
		//$this->testing();
		$obj = new static_testing();		
		$obj->testing();
		echo "<br>public variable value is: ".$obj->var1;
		echo "<br>static variable value is: ".self::$var2;
		echo "<br>constant variable value is: ".self::var3;
	}
	
	public function abc(){
		echo "hello i am here in public static function";
	}
	
}

//$static_obj = new static_testing();
//$static_obj->results();
//$static_obj->updated_results();
//$static_obj->abc();
//static_testing::abc();
//static_testing::updated_results();
//echo "<br>public variable value is: ".$static_obj->var1;
//echo "<br>static variable value is: ".static_testing::$var2;
//echo "<br>constant variable value is: ".static_testing::var3;





// Reference variables
class ref_test{
	public $a;
	protected $b;
	private $c;
	
	public function __construct(){
		$this->a = 1;
		$this->b = 2;
		$this->c = 3;
	}
	
	public function show(){
		echo "<br>public value is: ".$this->a;
		echo "<br>protected value is: ".$this->b;
		echo "<br>private value is: ".$this->c;
	}
}

$origional = new ref_test();
$assigned = $origional;

//$assigned->a = 5;
$referenced =& $origional;
//$referenced->a = 6;
//$origional = null;

//$origional->show();

//echo "<br><br><br>Assigned values are: <br>";

//$assigned->show();


//echo "<br><br><br>referenced values are: ";
//$origional_2 = new ref_test();

//$referenced->show();

//echo "<br><br><br>origional values are: ";
//$assigned->show();




//  Auto loading

class second_autoloading_class{
	public $e;
	public $f;
	
	public function __construct(){
		$this->e = "Hira" ;
		$this->f = "Nosheen";
	}
	
	function show(){
		echo "<br><br>from auto loading my full name is: ".$this->e." ".$this->f;
	}
}

function __autoload($classname){
	require_once($classname.".php");
}
//spl_autoload_register('');
//$first = new first_autoloading_class();
//$second = new second_autoloading_class();
//$third = new third_autoloading_class();

//echo "<br><br><br>at the end of the function";



class rehersal{
	
	public $first_name;
	public $last_name;
	static $withoutobj = "<br><br>I am without any object";
	
	public function __construct($fname, $lname){
		$this->first_name = $fname;
		$this->last_name = $lname;
	}
	
	public function __get($property){
		return $this->property ;
	}
	
	public function __set($property, $value){
		$this->property = $value;
	}
	
	protected function without_object(){
		echo "<br><br>This is calling without object<br><br>"; 
	}

}

class tmp{
	function temporary(){
		echo "<br><br>this is temporary function.<br><br>";
	}
}

class rehersal_child extends rehersal{
	public function __construct(){
	}
	public function show(){
		tmp::temporary();
	}
}

//$chk = new rehersal_child();
//$chk->show();

//echo rehersal::$withoutobj;
//rehersal::without_object();
//$rh_object = new rehersal('Aamir', "Rasheed");
//$rh_object->full_name = $rh_object->first_name." ".$rh_object->last_name ;
//echo "first name is: ".$rh_object->full_name;




echo "<br><br>PHP Manual object basics";
class Test
{
	public $tst;
	function __construct(){
		$this->a = "aamir";
		$this->b = "rasheed";
		$this->tst = function(){ return "this is a static function"; };
	}
	
    static public function getNew()
    {
        return "aamir";
    }
}

class Child extends Test
{}

$obj1 = new Test();
$value = $obj1->tst;
//echo "value of test variable is: ".$value();
//die;
//$obj2 = new $obj1;


//$obj3 = Test::getNew();
//var_dump($obj3 instanceof Test);

//$obj4 = Child::getNew();
//var_dump($obj4 instanceof Child);






class A {
   
    public  $x ;
	
	public function __construct(){
		$this->x = "A" ;
	}

    public function foo() {
        //$b = new B;
        //$b->bar();
        return $this->x;
    }
}

class B extends A {
    public function bar() {
        $this->x = 'B';
    }
}

$a = new B();

echo "<br><br>last testing value is: ".$a->foo();    
?>