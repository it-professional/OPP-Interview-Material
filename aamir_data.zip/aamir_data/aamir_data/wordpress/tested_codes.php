		<?php
global $current_user;
get_currentuserinfo();

//$wp_hasher = new PasswordHash(8, TRUE);

$password_hashed = $current_user->user_pass;
$plain_password = 'admin';


if(wp_check_password( $plain_password, $password_hashed) )
{
	echo "<br><b>Yes, Matched" ;
}
else
{
	echo "<br><b>No, Wrong Password";
}

echo "<br><br><br>";

/*if($wp_hasher->CheckPassword($plain_password, $password_hashed)) {
    echo "YES, Matched";
} else {
    echo "No, Wrong Password";
}
*/?>
		


<?php

$website = "http://example.com";
$userdata = array(
    'user_login'  =>  'login_name_7',
    'user_url'    =>  $website,
    'role'   =>  'administrator'  // When creating an user, `user_pass` is expected.
);

$user_id = wp_insert_user( $userdata ) ;

//On success
if ( ! is_wp_error( $user_id ) ) {
    echo "User created : ". $user_id;
}

?>