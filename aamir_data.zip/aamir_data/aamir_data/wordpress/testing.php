<?php
$string = "Aamir Rasheed";
echo "Orgional String is: <br>";
echo $string;
echo "<br><br><br><br>";

//echo chop($string,"A");

//echo chunk_split($string,1,'&nbsp;&nbsp;&nbsp;');

//$encoded = convert_uuencode($string);
//echo convert_uudecode($encoded);


//echo chr(101);

/*echo "0 value is: ";
print_r(count_chars($string,0))."<br><br><br>";

echo "<br><br><br>1 value is: ";
print_r(count_chars($string,1))."<br><br><br>";

echo "<br><br><br>2 value is: ";
print_r(count_chars($string,2))."<br><br><br>";

echo "<br><br><br>3 value is: ";
echo count_chars($string,3)."<br><br><br>";

echo "<br><br><br>4 value is: ";
echo count_chars($string,4)."<br><br><br>";
*/


//print_r(explode(" ",$string));


/*$num1 = 123456789;
$num3 = 123.456789;
$num2 = -123456789;
$char = 50; // The ASCII Character 50 is 2

//printf("%1\$b value is: %1\$b",$char);

printf("%%d value is %1\$d, <br> %%f value is %2\$f, <br>  %%u value is %2\$u",$num2, $num3);

printf("%%f value is %f",$num3);
echo "<br><br>";
printf("%%d value is %u",$num3);

// Note: The format value "%%" returns a percent sign
printf("%%b = %b <br>",$num1); // Binary number
printf("%%c = %c <br>",$char); // The ASCII Character
printf("%%d = %d <br>",$num1); // Signed decimal number
printf("%%d = %d <br>",$num2); // Signed decimal number
printf("%%e = %e <br>",$num1); // Scientific notation (lowercase)
printf("%%E = %E <br>",$num1); // Scientific notation (uppercase)
printf("%%u = %u <br>",$num1); // Unsigned decimal number (positive)
printf("%%u = %u <br>",$num2); // Unsigned decimal number (negative)
printf("%%f = %f <br>",$num1); // Floating-point number (local settings aware)
printf("%%F = %F <br>",$num1); // Floating-point number (not local settings aware)
printf("%%g = %g <br>",$num1); // Shorter of %e and %f
printf("%%G = %G <br>",$num1); // Shorter of %E and %f
printf("%%o = %o <br>",$num1); // Octal number
printf("%%s = %s <br>",$num1); // String
printf("%%x = %x <br>",$num1); // Hexadecimal number (lowercase)
printf("%%X = %X <br>",$num1); // Hexadecimal number (uppercase)
printf("%%+d = %+d <br>",$num1); // Sign specifier (positive)
printf("%%+d = %+d <br>",$num2); // Sign specifier (negative)

*/

/*$newstring = "Aamir<b>here</b><br>&nbsp;rasheed";
echo html_entity_decode($newstring);
echo "<br><br>HTML Entities";
echo htmlentities($newstring);
echo "<br><br><br>HTML Special Chars";
echo htmlspecialchars($newstring);
echo "<br><br><br>special chars decode<br>";
echo htmlspecialchars_decode($newstring);*/

/*$array = array("aamir","rasheed","hello");
echo join("<br>",$array);
*/

//$st = 1234.45;
//echo number_format($st,3) ;
//$array = array();


/*$stt = parse_str("name=aamir rasheed&age=32&class=MIT F06 M022",$array) ;
print_r($array['class']);*/

/*$str_1 = "Hello Man" ;
$str_2 = "Hello Woman" ;

$similarity = similar_text($str_1,$str_2,$percentage);
echo $percentage; */


//$number = 4;
//$devider = 2;
//$result = 2;
//$str = "If you divide 4 by 2 you'll get 2";
//sscanf($str, "if you divide number:%d by devisible:%u you' will get %f",$number,$devisible);
//var_dump($number,$devisible);




/*$input_string = 'Marks : Math - 88 :: Language - 75';  
$results = sscanf($input_string, '%s : Math - %d :: Language - %d');  
print_r($results);
//echo "<br><br>math value is: ".$math;
//echo "<br><br>language value is: ".$language;
//echo "<br><br>marks value is: ".$marks;
*/



/*$str = "Hello World";
echo str_pad($str,13,".");*/

//echo str_repeat("aamir <br>",10);

//$result = str_split($string,1);
//print_r($result);

//$result = str_word_count($string,2);
//print_r($result);


/*$result = strchr($string,"ee");
echo "result is: ".$result;*/

//echo strspn("abc defand","ef");

//echo stripos($string,"R");

//echo strstr($string,"as");

//echo strrev($string);


/*$string = "Hello world. Beautiful day today.";
$token = strtok($string, " ");

while ($token !== false)
{
echo "$token<br>";
$token = strtok(" ");
} */



//$substring = substr($string,0,6);
//echo $substring; 

//$str2 = "Rasheed" ;
//$substr = substr_compare($string,$str2,0);
//echo $substr; 


//$result = substr_count($string,"a");
//echo $result ;


//$result = substr_replace($string,"Muhammad",0,5);
//echo $result ;


//$str = "An example of a long word is: Supercalifragulistic";
//echo wordwrap($str,15);


//$a=array("A","Cat","Dog","A","Dog");
//print_r(array_count_values($a));


/*$a1=array("a"=>"red","b"=>"green","c"=>"blue","d"=>"yellow");
$result=array_flip($a1);
print_r($result);*/


/*$a=array("Volvo","BMW");
if (array_key_exists(0,$a))
  {
  echo "Key exists!";
  }
else
  {
  echo "Key does not exist!";
  }*/
  
 

//$a=array("color"=>"red",4=>"green");
//print_r(array_merge($a));  


/*$a=array("red","green","blue");
array_pop($a);
print_r($a);*/


/*$a=array("a"=>"red","b"=>"green");
array_push($a,"blue","yellow");
print_r($a);*/


//$a1=array("a"=>"red","b"=>"green");
//$a2=array("b"=>"orange","burgundy", 'a'=> 'yellow');
//print_r(array_replace($a1,$a2));


//$a1=array("a"=>"red","green");
//$a2=array("a"=>"orange","b"=>"burgundy");
//print_r(array_replace($a1,$a2));


/*$a1=array("red","green");
$a2=array("blue","yellow");
$a3=array("orange","burgundy");
print_r(array_replace($a1,$a2,$a3));*/


/*$a1=array("red","green","blue","yellow");
$a2=array(0=>"orange",3=>"burgundy");
print_r(array_replace($a1,$a2));*/


/*$a=array("Volvo","XC90",array("BMW","Toyota"));
$reverse=array_reverse($a);
$preserve=array_reverse($a,true);

print_r($a);
echo "<br><br><br>";
print_r($reverse);
echo "<br><br><br>";
print_r($preserve);*/


/*$a=array(0=>"red",1=>"green",2=>"blue");
echo array_shift($a);
print_r ($a);*/


$a=array("red","green","blue","yellow","brown");
print_r(array_slice($a,1,3));
?>