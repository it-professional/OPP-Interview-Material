<?php
require('testing6.php');

$object = new first\test\user\results\test();
$object->show();

echo "<br><br><br>second object<br><br>";
$object2 = new second\test\user\records\test();
$object2->show2();


echo "<br><br><br>Direct function testing<br><br>";
first\test\user\results\direct();
?>