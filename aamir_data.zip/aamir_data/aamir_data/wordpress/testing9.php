<?php /*?><?php
$con = mysqli_connect("localhost","root","","testing") or die('Error in SQL Connection');
$query = mysqli_query($con,'Call result_checking(4)');
if(mysqli_num_rows($query) > 0){
	while($row = mysqli_fetch_array($query)){
		echo "<br>subject id is: ".$row['sub_id'];
		echo "result is: ".$row['result'];
	}
}
?><?php */?>



<?php
/*try{
	$connection = new PDO("mysql:host=localhost;dbname=testing","root","");
}catch{
	$connection = new PDO("mysql:host=localhost;dbname=testing","root","");
}
*/

$connection = mysqli_connect("localhost","root","","testing") or die('Error in SQL Connection');
$query = mysqli_query($connection, "Select * From test where name = 'aamir''; Update test set age = 35 ;");
/*if(mysqli_num_rows($query) > 0){
	while($row = mysqli_fetch_array($query)){
		echo "<br><br>Name is: ".$row['name'];
		echo "<br>Age is: ".$row['age'];
	}
}
*/
?>