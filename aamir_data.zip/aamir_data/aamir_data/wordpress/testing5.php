<?php

/*$missing_no = '';
$integers = range(1,100);
$random_array = array_rand($integers,99);
for($i=1; $i<=100; $i++){
	if(!in_array($i,$random_array)){
		$missing_no = $i;
		break;
	}
}
echo "Missing Integer is: ".$missing_no ;*/


/*$number = 64;
$i=2;
$base = $power = '';
while($i < $number){
	if($number % $i == 0){
		$j = 1;
		while(true){
			if(pow($i, $j) > $number)
			{
				break;
			}elseif(pow($i, $j) == $number){
				$base = $i;
				$power = $j;
				break;
			}
			$j++;	
		}
	}
	$i++;
	if($base && $power){
		break;
	}
}*/

echo "<br><br>base value is: ".$base;
echo "<br><br>power value is: ".$power;

//for($i=11; $i<=100; $i++){
//echo ','.$i;
//}
?>