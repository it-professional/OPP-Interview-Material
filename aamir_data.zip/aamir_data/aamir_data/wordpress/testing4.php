<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Cookies Testing</title>
</head>
<body>
	<?php
    	//echo "<br><br>Here our normal code will be shown<br><br>";
		//echo "<br><br>current cookies value is: <br>";
		//print_r($_COOKIE);
		//echo "<br><br>set cookies value<br><br>";
		//setcookie('newtestname', 'nextbridge');
		//print_r($_COOKIE);
		
		$testing4_var1 = "testing 4 var 1";
		//include('testing3.php');
		
		$testing4_var2 = "testing 4 var 2";
		global $testing_global_Var;
		$testing_global_Var = "this is a global variable";
		
		
		//echo "<br><br>testing 3 string variable value is: ".$test_Var;
		
		//echo "time is: ".date('d/m/y');
		//echo "date is: ";
		//print_r(getdate());
		
		//echo "<br>current time is: ".mktime();
		
		/*$a = '1';
$b = &$a;
$b = "2$b";

echo "<br> A value is: ".$a;
echo "<br> B value is: ".$b;*/
		
/*function anothertest(){
	static $x = 1;
	echo "<br>x value is: ".$x;
	$x++;
}

echo "<br><br><br>first time function result is: ";
anothertest();
echo "<br><br><br>second time function result is: ";
anothertest();
echo "<br><br><br><br>third time function result is: ";
anothertest();
		
echo "<br><br><br><br><br>all global variables are: ";
*/

//print_r($GLOBALS);

//$connection = mysqli_connect("localhost","root",'',"testing");
//mysql_select_db('testing') or die('unable to connect the database');
//mysqli_query($connection,"Insert into test (name, age) Values ('ali',29), ('hira', 28), ('mehak',27)");
//mysqli_query($connection,"Delete from test where iid = 1");
/*$results = mysqli_query($connection,"Select name,age from test");
if(mysqli_num_rows($results)>0){
	echo "<br><br>new names are: ";
	while($row = mysqli_fetch_array($results)){
		echo "<br>name is: ".$row['name'];
	}
}
*/
/*$query = mysqli_query($connection,"Update test set name = 'aamir rasheed', age = 27 where iid = 2");
if($query){
	echo "<br><br>query executed successfully"; 
}else{
	echo "<br>there is some issue in query";
}
mysqli_close($connection);		
*/
/*try{
	$con = new PDO("mysql:host=localhost;dbname=testing","root","");
	//$insertion = $con->prepare("Insert into test(name, age) Values('nayab',26), ('ayesha',25), ('sufia',24)");
	//$insertion->execute();
	$results = $con->query("select * from test order by iid");
	$results->setFetchMode(PDO::FETCH_ASSOC)
	while($row = $results->fetch()){
		echo '<br><br>';
		echo "<br>name is: ".$row['name'];
	}
}catch(PDOException $e){
	echo $e->getMessage();
}*/




//  Stored Procedures  start

/*$sp_connection = mysqli_connect("localhost","root","","testing");
$query = mysqli_query($sp_connection, "Call testing(27)") or die("Error in Query ".mysqli_error());;
if(mysqli_num_rows($query) > 0){
	while($row = mysqli_fetch_array($query)){
		echo "<br><br>name is: ".$row['name'];
	}
}*/


//  Stored Procedures  end




// Autoloading class started from here
class first_autoloading_class{
	public $a;
	public $b;
	
	public function __construct(){
		$this->a = "aamir" ;
		$this->b = "rasheed";
	}
	
	function show(){
		echo "<br><br>from auto loading my full name is: ".$this->a." ".$this->b;
	}
}

class third_autoloading_class{
	public $e;
	public $f;
	
	public function __construct(){
		$this->e = "Hira" ;
		$this->f = "Nosheen";
	}
	
	function show(){
		echo "<br><br>from auto loading my full name is: ".$this->e." ".$this->f;
	}
}
?>
</body>
</html>