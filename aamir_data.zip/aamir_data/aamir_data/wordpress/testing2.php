<?php
$string = "Aamir Rasheed";
echo "Orgional String is: <br>";
echo $string;
echo "<br><br><br><br>";


//  Break the String

// Method 1
/*$results = str_split($string,1);
foreach($results as $result){
	echo "<br>".$result;
}*/


// Method 2
/*for($i=0; $i<strlen($string); $i++)
{
	echo "<br>".substr($string,$i,1);
}*/


// Method 3
//echo chunk_split($string,1,'<br>');





//  Count words from string


//  Method   1
//echo "a total time is: ".substr_count($string,'a');



// Method 2
/*$restults = count_chars($string,1);
foreach($restults as $key => $result){
	echo "<br>".chr($key)." = ".$result;
}*/
//echo "<br>results are: "; print_r($restults);
//$restults = count_chars($string,3);


/*$str = "aamir";
$string2 = "My name is %s and my father name is %1\$s" ;
//echo sprintf($string2,$str);
echo count($str);*/



//$input = array(4, "4", "3", 4, 3, "3");
//$result = array_unique($input);
//print_r($result);


/*$input = array("a" => "green", "red", "b" => "green", "red", "blue");
$result = array_unique($input);
print_r($result);*/



$favcolor = "redd";

/*
switch ($favcolor) {
    case "red":
        echo "Your favorite color is red!";
        break;
    default:
        echo "Your favorite color is neither red, blue, nor green!";
		break;
	case "red":
        echo "Your favorite color is Double Red!";
        break;
    case "green":
        echo "Your favorite color is green!";
        break;
}*/

//echo "<br><br>global variables are: ";
//print_r($GLOBALS);
?>