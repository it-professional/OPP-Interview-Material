<?php namespace first\test\user\results{
	function direct(){
		echo "<br><br>This is a direct function<br><br>";
	}
	
	class test{
		public function show(){
			echo "This is ".get_class($this);
		}
	}
}

namespace second\test\user\records{
	class test{
		public function show2(){
			echo "This is ".get_class($this);
		}
	}
}
?>